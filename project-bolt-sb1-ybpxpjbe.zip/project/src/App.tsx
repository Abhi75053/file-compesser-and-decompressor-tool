import React, { useState, useCallback } from 'react';
import { Archive, Sparkles, Github, Heart } from 'lucide-react';
import { FileUploader } from './components/FileUploader';
import { FileItem } from './components/FileItem';
import { ProcessingStats } from './components/ProcessingStats';
import { FileItem as FileItemType } from './types';
import { CompressionService } from './utils/compression';

function App() {
  const [files, setFiles] = useState<FileItemType[]>([]);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const handleFilesSelected = useCallback((selectedFiles: File[]) => {
    const newFiles: FileItemType[] = selectedFiles.map(file => ({
      id: generateId(),
      file,
      originalSize: file.size,
      status: 'pending',
      isCompressed: false,
      progress: 0
    }));
    
    setFiles(prev => [...prev, ...newFiles]);
  }, []);

  const updateFileStatus = (id: string, updates: Partial<FileItemType>) => {
    setFiles(prev => prev.map(file => 
      file.id === id ? { ...file, ...updates } : file
    ));
  };

  const simulateProgress = (id: string, callback: () => void) => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 15;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        updateFileStatus(id, { progress });
        setTimeout(callback, 500);
      } else {
        updateFileStatus(id, { progress });
      }
    }, 200);
  };

  const handleCompress = async (id: string) => {
    const fileItem = files.find(f => f.id === id);
    if (!fileItem) return;

    updateFileStatus(id, {
      status: 'processing',
      progress: 0
    });

    try {
      simulateProgress(id, async () => {
        const result = await CompressionService.compressFile(fileItem.file);
        
        updateFileStatus(id, {
          status: 'completed',
          compressedSize: result.compressedSize,
          compressionRatio: result.compressionRatio,
          isCompressed: true,
          progress: 100
        });

        // Auto-download the compressed file
        const filename = `${fileItem.file.name}.gz`;
        CompressionService.downloadFile(result.data, filename, 'application/gzip');
      });
    } catch (error) {
      updateFileStatus(id, {
        status: 'error',
        error: (error as Error).message,
        progress: 0
      });
    }
  };

  const handleDecompress = async (id: string) => {
    const fileItem = files.find(f => f.id === id);
    if (!fileItem) return;

    updateFileStatus(id, {
      status: 'processing',
      progress: 0
    });

    try {
      simulateProgress(id, async () => {
        const result = await CompressionService.decompressFile(fileItem.file);
        
        updateFileStatus(id, {
          status: 'completed',
          compressedSize: result.decompressedSize,
          compressionRatio: ((fileItem.originalSize - result.decompressedSize) / fileItem.originalSize) * 100,
          isCompressed: false,
          progress: 100
        });

        // Auto-download the decompressed file
        const filename = fileItem.file.name.replace(/\.(gz|zip|7z|rar)$/, '') || 'decompressed_file';
        CompressionService.downloadFile(result.data, filename);
      });
    } catch (error) {
      updateFileStatus(id, {
        status: 'error',
        error: (error as Error).message,
        progress: 0
      });
    }
  };

  const clearAllFiles = () => {
    setFiles([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200/50 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <Archive className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">File Compressor Pro</h1>
              <p className="text-sm text-gray-600">Compress & decompress files with ease</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Sparkles size={16} />
            <span>Advanced Compression Technology</span>
          </div>
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Compress Files with <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Lightning Speed</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Upload your files and watch them shrink in size without losing quality. 
            Perfect for saving storage space and faster file transfers.
          </p>
        </div>

        {/* File Uploader */}
        <div className="mb-8">
          <FileUploader
            onFilesSelected={handleFilesSelected}
            maxSize={100}
            multiple={true}
          />
        </div>

        {/* Processing Stats */}
        <ProcessingStats files={files} />

        {/* File List */}
        {files.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">
                Files ({files.length})
              </h3>
              <button
                onClick={clearAllFiles}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Clear All
              </button>
            </div>
            
            <div className="grid gap-4">
              {files.map(file => (
                <FileItem
                  key={file.id}
                  item={file}
                  onCompress={handleCompress}
                  onDecompress={handleDecompress}
                />
              ))}
            </div>
          </div>
        )}

        {/* Features Section */}
        {files.length === 0 && (
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Sparkles className="text-blue-600" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Fast Compression</h3>
              <p className="text-gray-600 text-sm">
                Advanced algorithms ensure maximum compression with minimal processing time.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Archive className="text-green-600" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Lossless Quality</h3>
              <p className="text-gray-600 text-sm">
                Preserve the original quality of your files while reducing their size significantly.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Github className="text-purple-600" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">Privacy First</h3>
              <p className="text-gray-600 text-sm">
                All processing happens locally in your browser. Your files never leave your device.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;