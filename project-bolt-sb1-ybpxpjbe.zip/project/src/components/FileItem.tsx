import React from 'react';
import { FileText, Download, Loader2, CheckCircle, XCircle, Zap } from 'lucide-react';
import { FileItem as FileItemType } from '../types';
import { CompressionService } from '../utils/compression';

interface FileItemProps {
  item: FileItemType;
  onCompress: (id: string) => void;
  onDecompress: (id: string) => void;
}

export const FileItem: React.FC<FileItemProps> = ({ item, onCompress, onDecompress }) => {
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusIcon = () => {
    switch (item.status) {
      case 'processing':
        return <Loader2 className="animate-spin text-blue-500" size={20} />;
      case 'completed':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'error':
        return <XCircle className="text-red-500" size={20} />;
      default:
        return <FileText className="text-gray-500" size={20} />;
    }
  };

  const handleDownload = () => {
    if (item.status === 'completed' && item.compressedSize) {
      // This would need the actual compressed data to work properly
      // In a real implementation, you'd store the compressed data
      console.log('Download would happen here');
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          {getStatusIcon()}
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-gray-900 truncate">
              {item.file.name}
            </h4>
            <p className="text-xs text-gray-500">
              {formatFileSize(item.originalSize)}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {item.status === 'pending' && (
            <>
              <button
                onClick={() => onCompress(item.id)}
                className="px-3 py-1 text-xs bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors flex items-center space-x-1"
              >
                <Zap size={12} />
                <span>Compress</span>
              </button>
              <button
                onClick={() => onDecompress(item.id)}
                className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded-full hover:bg-green-200 transition-colors flex items-center space-x-1"
              >
                <Zap size={12} />
                <span>Decompress</span>
              </button>
            </>
          )}
          
          {item.status === 'completed' && (
            <button
              onClick={handleDownload}
              className="px-3 py-1 text-xs bg-purple-100 text-purple-700 rounded-full hover:bg-purple-200 transition-colors flex items-center space-x-1"
            >
              <Download size={12} />
              <span>Download</span>
            </button>
          )}
        </div>
      </div>
      
      {item.status === 'processing' && (
        <div className="mb-3">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${item.progress}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">{item.progress}% complete</p>
        </div>
      )}
      
      {item.status === 'completed' && item.compressionRatio && (
        <div className="bg-gray-50 rounded-lg p-3">
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-gray-500">Original:</span>
              <span className="ml-1 font-medium">{formatFileSize(item.originalSize)}</span>
            </div>
            <div>
              <span className="text-gray-500">Compressed:</span>
              <span className="ml-1 font-medium">{formatFileSize(item.compressedSize || 0)}</span>
            </div>
          </div>
          <div className="mt-2 text-xs">
            <span className="text-gray-500">Compression:</span>
            <span className="ml-1 font-medium text-green-600">
              {item.compressionRatio.toFixed(1)}% smaller
            </span>
          </div>
        </div>
      )}
      
      {item.status === 'error' && item.error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-xs text-red-700">{item.error}</p>
        </div>
      )}
    </div>
  );
};