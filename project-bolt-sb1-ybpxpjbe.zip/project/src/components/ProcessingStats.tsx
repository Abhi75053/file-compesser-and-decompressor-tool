import React from 'react';
import { FileText, Zap, TrendingDown, Clock } from 'lucide-react';
import { FileItem } from '../types';

interface ProcessingStatsProps {
  files: FileItem[];
}

export const ProcessingStats: React.FC<ProcessingStatsProps> = ({ files }) => {
  const totalFiles = files.length;
  const completedFiles = files.filter(f => f.status === 'completed').length;
  const processingFiles = files.filter(f => f.status === 'processing').length;
  const errorFiles = files.filter(f => f.status === 'error').length;
  
  const totalOriginalSize = files.reduce((sum, f) => sum + f.originalSize, 0);
  const totalCompressedSize = files.reduce((sum, f) => sum + (f.compressedSize || 0), 0);
  const averageCompressionRatio = files.length > 0 
    ? files.reduce((sum, f) => sum + (f.compressionRatio || 0), 0) / files.length 
    : 0;

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (totalFiles === 0) return null;

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
        <Zap className="text-blue-500" size={20} />
        <span>Processing Statistics</span>
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center p-4 bg-blue-50 rounded-lg">
          <FileText className="mx-auto text-blue-600 mb-2" size={24} />
          <div className="text-2xl font-bold text-blue-700">{totalFiles}</div>
          <div className="text-xs text-blue-600">Total Files</div>
        </div>
        
        <div className="text-center p-4 bg-green-50 rounded-lg">
          <Clock className="mx-auto text-green-600 mb-2" size={24} />
          <div className="text-2xl font-bold text-green-700">{completedFiles}</div>
          <div className="text-xs text-green-600">Completed</div>
        </div>
        
        <div className="text-center p-4 bg-yellow-50 rounded-lg">
          <Zap className="mx-auto text-yellow-600 mb-2" size={24} />
          <div className="text-2xl font-bold text-yellow-700">{processingFiles}</div>
          <div className="text-xs text-yellow-600">Processing</div>
        </div>
        
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <TrendingDown className="mx-auto text-purple-600 mb-2" size={24} />
          <div className="text-2xl font-bold text-purple-700">
            {averageCompressionRatio.toFixed(1)}%
          </div>
          <div className="text-xs text-purple-600">Avg. Compression</div>
        </div>
      </div>
      
      {completedFiles > 0 && (
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Space Saved:</span>
            <span className="font-semibold text-green-600">
              {formatFileSize(totalOriginalSize - totalCompressedSize)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};