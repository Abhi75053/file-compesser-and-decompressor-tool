import pako from 'pako';

export class CompressionService {
  static async compressFile(file: File): Promise<{
    data: Uint8Array;
    originalSize: number;
    compressedSize: number;
    compressionRatio: number;
  }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        try {
          const arrayBuffer = event.target?.result as ArrayBuffer;
          const uint8Array = new Uint8Array(arrayBuffer);
          
          // Compress using pako (gzip)
          const compressed = pako.deflate(uint8Array, { level: 9 });
          
          const originalSize = uint8Array.length;
          const compressedSize = compressed.length;
          const compressionRatio = ((originalSize - compressedSize) / originalSize) * 100;
          
          resolve({
            data: compressed,
            originalSize,
            compressedSize,
            compressionRatio
          });
        } catch (error) {
          reject(new Error('Compression failed: ' + (error as Error).message));
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsArrayBuffer(file);
    });
  }

  static async decompressFile(file: File): Promise<{
    data: Uint8Array;
    originalSize: number;
    decompressedSize: number;
  }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        try {
          const arrayBuffer = event.target?.result as ArrayBuffer;
          const uint8Array = new Uint8Array(arrayBuffer);
          
          // Decompress using pako
          const decompressed = pako.inflate(uint8Array);
          
          const originalSize = uint8Array.length;
          const decompressedSize = decompressed.length;
          
          resolve({
            data: decompressed,
            originalSize,
            decompressedSize
          });
        } catch (error) {
          reject(new Error('Decompression failed: ' + (error as Error).message));
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsArrayBuffer(file);
    });
  }

  static downloadFile(data: Uint8Array, filename: string, mimeType: string = 'application/octet-stream') {
    const blob = new Blob([data], { type: mimeType });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
  }
}